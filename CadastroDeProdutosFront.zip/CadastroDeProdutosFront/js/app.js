document.addEventListener("DOMContentLoaded", function() {
    const apiBaseUrl = 'https://localhost:5001/api/v1/CadastroProdutos';

    // Função para buscar produtos da API
    function fetchProducts() {
        fetch(apiBaseUrl)
            .then(response => response.json())
            .then(data => {
                displayProducts(data);
            })
            .catch(error => console.error('Erro ao buscar produtos:', error));
    }

    // Função para exibir os produtos
    function displayProducts(products) {
        const productList = document.getElementById('product-list');
        productList.innerHTML = '';

        products.forEach(product => {
            const productCard = document.createElement('div');
            productCard.className = 'product-card';
            productCard.innerHTML = `
                <h2>${product.nome}</h2>
                <p>${product.descricao}</p>
                <p>Preço: R$ ${product.preco.toFixed(2)}</p>
                <p>Quantidade: ${product.quantidade}</p>
                <button onclick="editProduct(${product.id})">Editar</button>
                <button onclick="deleteProduct(${product.id})">Excluir</button>
            `;
            productList.appendChild(productCard);
        });
    }

    // Função para excluir um produto
    function deleteProduct(productId) {
        fetch(`${apiBaseUrl}/${productId}`, {
            method: 'DELETE'
        })
        .then(response => {
            if (response.ok) {
                alert('Produto excluído com sucesso!');
                fetchProducts();
            } else {
                alert('Erro ao excluir produto');
            }
        })
        .catch(error => console.error('Erro ao excluir produto:', error));
    }

    // Função para editar um produto (apenas um exemplo simples)
    function editProduct(productId) {
        const newName = prompt('Digite o novo nome do produto:');
        const newDescription = prompt('Digite a nova descrição do produto:');
        const newPrice = prompt('Digite o novo preço do produto:');
        const newQuantity = prompt('Digite a nova quantidade do produto:');

        const updatedProduct = {
            id: productId,
            nome: newName,
            descricao: newDescription,
            preco: parseFloat(newPrice),
            quantidade: parseInt(newQuantity)
        };

        fetch(`${apiBaseUrl}/${productId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedProduct)
        })
        .then(response => {
            if (response.ok) {
                alert('Produto atualizado com sucesso!');
                fetchProducts();
            } else {
                alert('Erro ao atualizar produto');
            }
        })
        .catch(error => console.error('Erro ao atualizar produto:', error));
    }

    // Carregar produtos ao carregar a página
    fetchProducts();

    // Tornar funções editProduct e deleteProduct globais
    window.editProduct = editProduct;
    window.deleteProduct = deleteProduct;
});
